

<?php

	$connection = mysqli_connect("localhost", "root", "", "stocks");
	
	$id=$_POST['id'];

	$query = "DELETE FROM tbl_products  WHERE id = '$id'";

    mysqli_query($connection, $query);

?>